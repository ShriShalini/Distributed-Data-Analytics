
from mpi4py import MPI
import numpy as np
import random

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()
number_of_processes = size
theta = np.zeros((483, 1))
prev_cost = float("inf")
cost = 0
local_convergence = 0
converged_flag = 0
fflag = 0
epochs_cost = []
print('my rank',rank)
def derivative(predicted_output, actual_output, theta, dataset,j,iteration):
    #print(type(actual_output[0][0]), type(predicted_output[0][0]))

    difference = np.subtract(actual_output,predicted_output)


    term0 = (2*((difference**2)**0.5))

    a = np.ones((len(difference),1))

    term1 = np.divide(a, term0, out=np.zeros_like(a), where=term0 != 0)

    term2 = ((2 * difference * (-1 * dataset[j])))

    term1 = term1.T

    derivative_gradient = (np.dot(term1, term2))
    return derivative_gradient


if(rank == 0):
    #print('rank 0')
    dataset = []
    file = open('2010-11.txt', 'r')
    actual_output = []
    content = file.readlines()
    i = 0

    #cleaning the data
    for x in content:
        # if(i==0):
        #    i=i+1
        x = x.split(' ')
        inter_data = [0] * 482
        for y in x:


            if (':' not in y):
                if ('\n' not in y):
                    actual_output.append(float(y))
                # print(y)
            else:
                if (i == 1):
                    pass
                    # print(y)

                l = y.split(':')
                inter_data[int(l[0])] = float(l[1])
        inter_data = np.insert(inter_data, 0, 1, axis=0)
        dataset.append(inter_data)
        #print(len(dataset),len(dataset[0]))
    splitted_array = np.array_split(dataset, number_of_processes)
    actual_output_split = np.array_split(actual_output,number_of_processes)



else:
    splitted_array = None
    actual_output_split = None
    #print('rank',rank)

splitted_array = comm.scatter(splitted_array,root = 0)
actual_output_split = comm.scatter(actual_output_split,root=0)


epoch = 0
start = MPI.Wtime()
while(True):

    if (epoch != 0):

        theta = new_arr


    predicted_output = (np.dot(splitted_array, theta))

    random.shuffle(splitted_array)
    actual_output_split = np.reshape(actual_output_split, (len(predicted_output), 1))

    if(local_convergence!=1):

        for i in range(0, len(splitted_array)):

            derivative_gradient = derivative(predicted_output, actual_output_split, theta, splitted_array, i, epoch)
            learning_rate = 10**-12


            theta = theta.T - learning_rate * derivative_gradient
            theta = theta.T
        predicted_output = (np.dot(splitted_array, theta))
        cost = (np.sum((actual_output_split - predicted_output) ** 2) / len(splitted_array)) ** 0.5

        print('prev cost',prev_cost,'cost',cost)

        if (prev_cost-cost<=10**-5):

            flag = 1
            converged_flag+=1
            local_convergence = 1

    else:

        con= None
    con = None
    con = comm.gather(converged_flag,root=0)
    cost_process = None
    cost_process = comm.gather(cost, root=0)

    if(rank==0):

        fflag=0
        for i in range(0,len(con)):
            if(con[i]==1):
                fflag+=1

        if(fflag==number_of_processes):
            break

    prev_cost = cost

    array_gathered = comm.gather(theta)

    if (rank == 0):
        #print('gathered arrayy', len(array_gathered))
        array_gathered = np.array(array_gathered)
        if (array_gathered.ndim > 1):
            array_gathered = np.sum(array_gathered, axis=0)
            array_gathered = np.divide(array_gathered, number_of_processes)
            #print('computer local model',epoch,array_gathered)
    else:
        new_arr = None
    new_arr = comm.bcast(array_gathered)
    cost_process  = np.array(cost_process)
    print('epoch',epoch,'cost',np.sum(cost_process))
    epochs_cost.append(np.sum(cost_process))
    epoch += 1


predicted_output = (np.dot(dataset, theta))
cost = (np.sum((actual_output - predicted_output) ** 2) / len(splitted_array)) ** 0.5

print('epoch and costs associated',epochs_cost)

print('time taken',MPI.Wtime()-start)

#testing
if(rank == 0):
    #print('rank 0')
    testdataset = []
    file = open('2010-12.txt', 'r')
    actual_output = []
    content = file.readlines()
    i = 0
    # theta initialization

    for x in content:
        # if(i==0):
        #    i=i+1
        x = x.split(' ')
        inter_data = [0] * 482
        for y in x:
            # print('item',y)

            if (':' not in y):
                if ('\n' not in y):
                    actual_output.append(float(y))
                # print(y)
            else:
                if (i == 1):
                    pass
                    # print(y)

                l = y.split(':')
                inter_data[int(l[0])] = float(l[1])
        inter_data = np.insert(inter_data, 0, 1, axis=0)
        testdataset.append(inter_data)

    splitted_array = np.array_split(testdataset, number_of_processes)
    actual_output_split = np.array_split(actual_output,number_of_processes)



predicted_output = (np.dot(testdataset, theta))
cost = (np.sum((actual_output - predicted_output) ** 2) / len(splitted_array)) ** 0.5
print('cost on test set',cost)