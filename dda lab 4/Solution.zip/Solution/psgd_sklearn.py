from sklearn.linear_model import SGDRegressor
from mpi4py import MPI
import numpy as np
import random

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()
number_of_processes = size
theta = np.zeros((483, 1))
prev_cost = float("inf")
cost = 0
local_convergence = 0
converged_flag = 0
fflag = 0
epochs_cost = []
print('my rank',rank)

start = MPI.Wtime()
if(rank == 0):
    #print('rank 0')
    dataset = []
    file = open('2010-12.txt', 'r')
    actual_output = []
    content = file.readlines()
    i = 0
    # theta initialization

    for x in content:
        # if(i==0):
        #    i=i+1
        x = x.split(' ')
        inter_data = [0] * 482
        for y in x:
            # print('item',y)

            if (':' not in y):
                if ('\n' not in y):
                    actual_output.append(float(y))
                # print(y)
            else:
                if (i == 1):
                    pass
                    # print(y)

                l = y.split(':')
                inter_data[int(l[0])] = float(l[1])
        inter_data = np.insert(inter_data, 0, 1, axis=0)
        dataset.append(inter_data)
        #print(len(dataset),len(dataset[0]))
    splitted_array = np.array_split(dataset, number_of_processes)
    actual_output_split = np.array_split(actual_output,number_of_processes)


sgd_reg = SGDRegressor(max_iter=63, penalty=None, eta0=10**-15)
sgd_reg.fit(dataset,actual_output)
print(sgd_reg.intercept_,)
print( sgd_reg.coef_)
#np.insert(sgd_reg.coef_)
predicted_output = (np.dot(dataset, sgd_reg.coef_))
cost = (np.sum((actual_output - predicted_output) ** 2) / len(splitted_array)) ** 0.5
print('cost',cost)
print('time',MPI.Wtime()-start)