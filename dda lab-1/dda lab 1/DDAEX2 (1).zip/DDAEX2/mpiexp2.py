#MAtrix multiplication

from mpi4py import MPI
import numpy as np

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()
print('rank',rank)
n=10**4
np.random.seed(4)
matrix_a = np.random.random((n,n))
vector_a = np.random.random((n,1))

vector_b = []
elements_per_process = n//size
index = 0
time = MPI.Wtime()
if(rank==0):
    if(size==1):
        print('final product',np.dot(matrix_a,vector_a))
    if(size>1):
        index_start = index_end = 0
        #print('size greater tjan 1')
        for i in range(1,size):
            if(i!=size-1):
                
                index_start = i*elements_per_process   
                index_end = index_start + elements_per_process 
                #index_end = index_start+elements_per_process
                row_id2 = np.array([i for i in range(index_start,index_end)])
                col_idx = np.array([j for j in range(0,n)])
                #print('rowcolun',row_id2,col_idx)
                matrix_to_send = matrix_a[row_id2[:, None], col_idx]
                #print('sent',matrix_to_send,i)
                comm.Send([matrix_to_send,MPI.FLOAT],dest = i)
            else:
                index_start = i*elements_per_process   
                
                #print('index_end',index_end)
                remaining_elements = n-index
                row_idx = np.array([i for i in range(index_start, n)])
                col_idx = np.array([j for j in range(0,n)])
                #print(row_idx,col_idx)
                matrix_to_send = matrix_a[row_idx[:, None], col_idx]
                #print('sendo',matrix_to_send.shape,i)
                #print('blocked')
                comm.Send([matrix_to_send,MPI.FLOAT],dest=i)
        
        #master computes its operation
        row_id2 = np.array([i for i in range(0,elements_per_process)])
        col_idx = np.array([j for j in range(0,n)])
        matrix_to_send = matrix_a[row_id2[:, None], col_idx]
        result_0 = np.dot(matrix_to_send,vector_a)
        #print('result',result_0)
        """
        index = index_end
        remaining_elements = n-index
        row_idx = np.array([i for i in range(index, n)])
        col_idx = np.array([j for j in range(0,n)])
        print(row_idx,col_idx)
        matrix_to_send = matrix_a[2:n]
        print('sendo',matrix_to_send,i)
        print('blocked')
        comm.Send([matrix_to_send,MPI.FLOAT],dest=i)
        """
        
        #master computes its operation
        result_0 = np.dot(matrix_to_send,vector_a)
        print('result from rank 0',result_0)
        final_product = np.array(result_0)
        temp = []
        for i in range(1,size):
            if(i!=size-1):
                elem = elements_per_process
                data_buffer = np.empty((elem,1),dtype=float)
                comm.Recv([data_buffer,MPI.FLOAT],source=i)
                
            else:
                elem = i*elements_per_process
                data_buffer = np.empty((n-elem,1),dtype=float) 
                comm.Recv([data_buffer,MPI.FLOAT],source=i)
            #print('revd',data_buffer)
            #data_buffer = np.empty((elem,1),dtype=float)  
            
            #print('shapes',result_0,data_buffer)
            final_product = np.append(final_product,data_buffer,axis=0)
            
        print('final product',final_product)  
             


        
else:
    
    
    index_start = rank-1
    #print('indexstart',index_start)
    #print('nindex',n-index_start)
    if(rank!=size-1):
        data_buffer2 = np.empty((elements_per_process,n),dtype=float)
        comm.Recv([data_buffer2,MPI.FLOAT],source = 0)
    else:
        
        elem = rank*elements_per_process
        #print('entered',elem)
        data_buffer2 = np.empty((n-elem,n),dtype=float)
        comm.Recv([data_buffer2,MPI.FLOAT],source = 0)
        #print(data_buffer2.shape)
    #print('shape0',data_buffer2,vector_a)
    result_prod = np.dot(data_buffer2,vector_a)
    print('result for rank',rank,' ',result_prod)
    comm.Send([result_prod,MPI.FLOAT],dest = 0)
    
    
print('time',MPI.Wtime()-time)
























