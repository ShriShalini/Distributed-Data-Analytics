
from mpi4py import MPI
import numpy as np
comm = MPI.COMM_WORLD
size = comm.Get_size()
rank = comm.Get_rank()
n = 10**3
np.random.seed(4)
data2 = np.random.random((n,n))
#print('matrix2',data2)
if rank == 0:
   data = np.random.random((n,n))
   
else:
   data = None
#broadcasting matrix 1
data = comm.bcast(data, root=0)
data += 1

elements_per_process = n//size
prod_matrix = []
time = MPI.Wtime()
if(rank!=0):
    if(rank!=size-1):
        
        i=rank
        index_start = i*elements_per_process   
        index_end = index_start + elements_per_process 
        
        row_id2 = np.array([i for i in range(index_start,index_end)])
        col_idx = np.array([j for j in range(0,n)])
        
        matrix_to_send = data[row_id2[:, None], col_idx]
        
    else:
        
        i = rank
        index_start = i*elements_per_process   
            
        row_idx = np.array([i for i in range(index_start, n)])
        col_idx = np.array([j for j in range(0,n)])
        
        matrix_to_send = data[row_idx[:, None], col_idx]
        
    print('Process {} has been given this data:'.format(rank), matrix_to_send)
    
    #prod = np.dot(matrix_to_send,data2)
    N=np. size(matrix_to_send, 0)
    BM = np.size(data2,1)
    C = [[0 for c in range(0,BM)] for r in range(0,N)]
    for n in range(0,N):
        for m in range(0,BM):
            val = 0
            for k in range(0,BM):
                val+= matrix_to_send[n][k] * data2[k][m]
            C[n][m] = val
    
    #prod_matrix.append(prod)
    
else:
    row_id2 = np.array([i for i in range(0,elements_per_process)])
    col_idx = np.array([j for j in range(0,n)])
    
    matrix_to_send = data[row_id2[:, None], col_idx]
    print('Process {} has been given this data:'.format(rank), matrix_to_send)
    #prod = np.dot(matrix_to_send,data2)
    #prod_matrix.append(prod)
    N=np. size(matrix_to_send, 0)
    BM = np.size(data2,1)
    C = [[0 for c in range(0,BM)] for r in range(0,N)]
    for n in range(0,N):
        for m in range(0,BM):
            val = 0
            for k in range(0,BM):
                val+= matrix_to_send[n][k] * data2[k][m]
            C[n][m] = val
    

#gathering data
newData = comm.allgather(C)


if rank == 0:
   print('Matrix multiplication:',np.array(newData))
   
   
print('time',MPI.Wtime()-time)