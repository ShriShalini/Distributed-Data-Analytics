#VECTOR ADDITION
from mpi4py import MPI
import numpy as np

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()
print('rank',rank)
np.random.seed(4)
n=10**12
#print(n)
matrix_a = np.random.random((2,n))

elements_per_process = n//size
if rank==0:
    
    wt = MPI.Wtime()
    if(size==1):
        print(np.sum(matrix_a[:],axis=0))
        print('Time elapsed',MPI.Wtime()-wt)

    if(size>1):
        
        for i in range(1,size):
            #Distributing the data among the slaves
            if(i!=size-1):
                
                index_start = i*elements_per_process   
                index_end = index_start + elements_per_process 
           
                row_id2 = np.array([i for i in range(0,2)])
                col_idx = np.array([j for j in range(index_start,index_end)])
                matrix_to_send = matrix_a[row_id2[:, None], col_idx]
                comm.Send([matrix_to_send,MPI.FLOAT],dest = i)
            else:
                index_start = i*elements_per_process
                row_idx = np.array([i for i in range(0, 2)])
                col_idx = np.array([j for j in range(index_start,n)])
                matrix_to_send = matrix_a[row_idx[:, None], col_idx]
                comm.Send([matrix_to_send,MPI.FLOAT],dest=i)

        #master computes addition operation
        row_id2 = np.array([i for i in range(0,2)])
        
        col_idx = np.array([j for j in range(0,elements_per_process)])
        matrix_to_send = matrix_a[row_id2,:][:,[col_idx]]
        
        result = np.sum(matrix_to_send,axis=0)
        print('result from rank 0',result)
        print()
        final_sum = np.array(result)
        #Master receives results from slaves
        for i in range(1,size):
            if(i!=size-1):
                elem = elements_per_process
                data_buffer = np.empty((1,elem),dtype=float)
                comm.Recv([data_buffer,MPI.FLOAT],source=i)
                
            else:
                elem = i*elements_per_process
                data_buffer = np.empty((1,n-elem),dtype=float) 
                comm.Recv([data_buffer,MPI.FLOAT],source=i)
        
            if(i!=size-1):
                final_sum = np.append(final_sum,data_buffer,axis=1)
            else:
                final_sum = np.append(final_sum,data_buffer,axis=1)
        
        print('Vector addition',final_sum)  
        print('Time elapsed',MPI.Wtime()-wt)
                
            
else:
    
    #computing vector addition in individual slaves
    index_start = rank-1
    if(rank!=size-1):
        data_buffer2 = np.empty((2,elements_per_process),dtype=float)
        comm.Recv([data_buffer2,MPI.FLOAT],source = 0)
    else:
        
        elem = rank*elements_per_process
        #print('entered',elem)
        data_buffer2 = np.empty((2,n-elem),dtype=float)
        comm.Recv([data_buffer2,MPI.FLOAT],source = 0)
        #print(data_buffer2.shape)
    #Sending results of addition to master 	
    result_sum = np.sum(data_buffer2[:],axis=0)
    print('result for rank',rank,' ',result_sum)
    print()
    comm.Send([result_sum,MPI.FLOAT],dest = 0)
                      
                    
            
    
    
