import sys

# input comes from STDIN (standard input)
import csv
import sys

for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    # split the line into words
    words = line.split(',')
    words[4] = words[4].strip('\"')
    
    print('%s\t%s' % (words[4],words[8]))
    
