#!/usr/bin/env python
"""reducer.py"""

from operator import itemgetter
import sys

current_airport = None
current_depdelay = 0
count = 0
avg_arrival_delay = []
# input comes from STDIN
l = []
count  = 0
for line in sys.stdin:
    #parsing input for reducer from stdin
    airport, depdelay = line.split('\t', 1)
    #removing white spaces
    line = line.strip()
    #converting string to float
    try:
        depdelay = float(depdelay)
    except ValueError:
        continue

    #current_airport initially None, but eventually gets updated with airport from stdin in line37
    if current_airport == airport:
        #adding delays to calculate average
        current_depdelay += depdelay
        count +=1
    else:
        if current_airport:
            #averge delay calculation
            print("Current airport",current_airport)
            print('Average delay %s' % (current_depdelay/(count+1)))
            avg_arrival_delay.append((current_depdelay/(count+1),current_airport))
            count = 0
        current_airport = airport
        current_depdelay = depdelay

#adding the final airport's final delay
if current_airport == airport:
    print("Current airport", current_airport)
    print('Average delay')
    print('%s' % (current_depdelay / (count + 1)))
    avg_arrival_delay.append(( current_depdelay / (count + 1),current_airport))

#Computing top 10 average delays
print('Top 10 airport\'s average arrival delay',avg_arrival_delay[0:10])
avg_arrival_delay = (sorted(avg_arrival_delay))
print('Top ten airports with minimum average delay',avg_arrival_delay[0:10])