#!/usr/bin/env python
"""reducer.py"""

from operator import itemgetter
import sys

current_airport = None
current_depdelay = 0
count = 0
min_delay = float("inf")
max_delay = float("-inf")
#word = None

# input comes from STDIN
l = []
count  = 0
for line in sys.stdin:
    airport, depdelay = line.split('\t', 1)
    #print(airport, depdelay)


    # remove leading and trailing whitespace
    line = line.strip()

    # parse the input we got from mapper.py
    # word, count = line.split('\t', 1)
    # print('word and its count', word,count)
    # #l.append([word,count])
    #print(current_airport, current_depdelay)
    #convert count (currently a string) to int
    try:
        depdelay = float(depdelay)
    except ValueError:
        # count was not a number, so silently
        # ignore/discard this line
        continue
    if (depdelay <= min_delay):
        min_delay = depdelay
    if (depdelay >= max_delay):
        max_delay = depdelay
    #print('current airport is',current_airport)
    #this IF-switch only works because Hadoop sorts map output
    #by key (here: word) before it is passed to the reducer
    if current_airport == airport:
        current_depdelay += depdelay
        count +=1
    else:
        if current_airport:
            # write result to STDOUT
            print("Current airport",current_airport)
            print('Average Delay %s' % (current_depdelay/(count+1)))
            count = 0
            if (depdelay <= min_delay):
                min_delay = depdelay
            if (depdelay >= max_delay):
                max_delay = depdelay
            print("Min delay")
            print('%s' % (min_delay))
            print("Max delay")
            print('%s' % (max_delay))
            min_delay = float("inf")
            max_delay = float("-inf")
        current_airport = airport
        current_depdelay = depdelay

#do not forget to output the last word if needed!
if current_airport == airport:
    max_delay = float("-inf")
    min_delay = float("inf")
    print("Current airport", current_airport)
    print('Average delay')
    print('%s' % (current_depdelay / (count + 1)))
    if (depdelay <= min_delay):
        min_delay = depdelay
    if (depdelay >= max_delay):
        max_delay = depdelay
    print("Min delay")
    print('%s' % (min_delay))
    print("Max delay")
    print('%s' % (max_delay))
#print(word,count)