
import sys

for line in sys.stdin:
    # removing white space
    line = line.strip()
    # using line split with comma as delimiter
    words = line.split(',')
    #printing key value pairs with '\t' in between
    print('%s\t%s' % (words[3],words[6]))