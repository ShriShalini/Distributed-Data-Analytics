

from operator import itemgetter
import sys

current_word = None
current_count = 0
word = None
#reading input from mapper via the input stream
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    #getting the word from the mapper
    word, count = line.split('\t', 1)
    #string to float
    try:
        count = int(count)
    except ValueError:
        continue
    print('%s\t%s' % (word, count))
