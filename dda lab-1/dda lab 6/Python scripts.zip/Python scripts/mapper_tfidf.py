

import sys
import os
import re
import string
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from operator import itemgetter
import sys
stop_words = set(stopwords.words('english'))

#reading input from input stream
for line in sys.stdin:
    #removing leading and trailing white spaces
    line = re.sub('[^a-zA-Z \n\.]', ' ', line)
    #removing punctuations
    chars = re.escape(string.punctuation)
    line = re.sub(r'[' + chars + ']', ' ', line)
    line = line.strip()
    #tokenizing the text from the text files
    word_tokens = word_tokenize(line)
    line = [w for w in word_tokens if not w.lower() in stop_words]
    # passing the cleaned text to the reducer with the name of the input text file
    for word in line:
        filename = os.environ["map_input_file"]

        print(word,'\t',filename)
