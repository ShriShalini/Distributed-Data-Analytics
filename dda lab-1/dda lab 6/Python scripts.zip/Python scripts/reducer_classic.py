

from operator import itemgetter
import sys

current_word = None
current_count = 0
word = None
#reading input from mapper via the input stream
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    #getting the word from the mapper
    word, count = line.split('\t', 1)
    #string to float
    try:
        count = int(count)
    except ValueError:
        continue

    #inncrementing count as long as the same word is seen
    if current_word == word:
        current_count += count
    else:
        #printing a word and its count
        if current_word:
            print('%s\t%s' % (current_word, current_count))
        current_count = count
        current_word = word

#printing the word and the output of the last word.
if current_word == word:
    print('%s\t%s' % (current_word, current_count))


