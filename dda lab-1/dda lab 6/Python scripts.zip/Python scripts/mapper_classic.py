

import sys
import re
import os
import string
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from operator import itemgetter

stop_words = set(stopwords.words('english'))

#reading input from stdin
for line in sys.stdin:
    #removing anything other than letters, line breaks, period
    line = re.sub('[^a-zA-Z \n\.]', ' ', line)
    #escaping punctuation from strings
    chars = re.escape(string.punctuation)
    line = re.sub(r'[' + chars + ']', ' ', line)
    #removing the leading and trailing white spaces
    line = line.strip()
    #tokenizing the line
    word_tokens = word_tokenize(line)
    #removing stop words
    line = [w for w in word_tokens if not w.lower() in stop_words]
    #printing words to the output
    for word in line:
        print('%s\t%s' % (word, 1))