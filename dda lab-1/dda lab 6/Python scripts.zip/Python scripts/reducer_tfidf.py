import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from operator import itemgetter
import sys
stop_words = set(stopwords.words('english')) 
current_word = None
current_count = 0
word = None
docdict= {}
tf_dict = [dict(),dict(),dict(),dict(),dict()]
idfdict = dict()


for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()

    #interpreting the word and the document in which the word was present
    word, document = line.split('\t')
    word = word.strip()

    #calculating the word and its count for a single file and maintaining a dictionary with words as keys and the number of documents in which the word was present as values.
    if document not in docdict:
        docdict[document] = {}
    else:
        if word not in docdict[document]:
            docdict[document][word]  = 1
            if word not in idfdict:
                idfdict[word]=1
            else:
                idfdict[word]+=1
        else:
            docdict[document][word]+=1

print('%s' % len(docdict))
#calculating tfidf scores
for doc,dict in docdict.items():
    #iterating - word in document level
    print('current document',doc,len(docdict[doc]))
    for key,value in dict.items():
        tf = value/sum(docdict[doc].values())
        idf = np.log(5/idfdict[key])
        print('tfidf for',key,':',tf*idf)



