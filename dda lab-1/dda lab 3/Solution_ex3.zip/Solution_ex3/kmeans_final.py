from mpi4py import MPI
import numpy as np
import csv 
import matplotlib.pyplot as plt
import math
import sys
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

def dist(centroid,data):
    
    distar = []
    sum = 0
    for i in range(0,len(centroid)):
        sum+=(centroid[i]-data[i])**2 
    return math.sqrt(sum)

def member(distar):
    return distar.index(min(distar))
    
filename = "Absenteeism_at_work.csv"
args_list = sys.argv 

#initializing rows list
rows = [] 
centroid_count = int(args_list[1])

# reading csv file 
with open(filename, 'r') as csvfile: 
    #csv reader object 
    csvreader = csv.reader(csvfile) 
      
    #field names are ignored
    row0_with_field_names = next(csvreader) 
  
    # extracting data row by row
    for row in csvreader: 
        row_list = row[0].split(';')
        row_list = list(map(float,row_list))
        rows.append(row_list) 

if(rank==0):
    centroid = rows[100:100+centroid_count]
    array = np.array_split(rows[0:],size)        
else:
    array = None
    centroid = None
#Broadcasting centroids
centroid = comm.bcast(centroid,root = 0)
#Scattering the input array among the workers
array = comm.scatter(array)

#initializations
flag = 0
n_centroid = None
m = 0
i = 0
while(True):
    #iteration count
    i=i+1
	
    flag = 0
	#assigning centroid with the newly_calculated centroid from process 0
    for i in range(0,len(centroid)):
        for j in range(0,len(centroid[0])):
            if(m!=0 and centroid[i][j] != n_centroid[i][j]):
                centroid = n_centroid
                flag = 1
                break
	#breaking on convergence
    if(m!=0 and flag==0):
        
        if(rank == 0):
            print('Convergence in',i,'iterations')
            print('Old centroid', centroid)
            print('New centroid', n_centroid)
        break
		
    m =1
    centroid_sum = [0]*len(centroid)
    centroid_num = [0]*len(centroid)
    #clustering based on distance
    for i in range(0,len(array)):
        d = []
        for j in range(0,len(centroid)):
            d.append(dist(centroid[j],array[i]))   
        mem = member(d)
        centroid_sum[mem]+=array[i]
        centroid_num[mem]+=1
	#calculating local mean
    local_centroids = []
    for i in range(0,len(centroid_sum)):
        if(centroid_num[i]!=0):
            local_centroids.append(centroid_sum[i]/centroid_num[i])
        else:
            local_centroids.append(np.array([0.0]*21))
	#calculation of global mean starts after computing all local means
    comm.Barrier()
    #communicating the local mean with rank 0
    gathered_centroids = comm.gather(local_centroids,root=0)
	#calculating the global mean
    if rank == 0:   
        final_centroids = [0]*centroid_count
        for i in range(0,len(gathered_centroids[0])):
            for j in range(0,len(gathered_centroids)):
                final_centroids[i]+=gathered_centroids[j][i]
            final_centroids[i]/=len(gathered_centroids)
    else:
        n_centroid = None 
        final_centroids = None
	#Broadcasting the newly found centroids
    n_centroid = comm.bcast(final_centroids,root =0)
	
    

    
    


    








































    