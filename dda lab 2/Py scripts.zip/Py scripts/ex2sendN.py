#Nsend
from mpi4py import MPI
import numpy as np
import sys

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()



args = list(sys.argv)
np.random.seed(4)
n = int(args[1])
array = np.random.random((1,n))


 
def NsendAll(array,time):
    
    if rank==0:
    
        for i in range(1,size):
            
            comm.Send([array,MPI.FLOAT],dest=i)

    else:
        data_buffer = np.empty((1,n),dtype=float)
        comm.Recv([data_buffer,MPI.FLOAT],source=0)
        
    comm.Barrier() #MAKES ALL TIME2 STRICTLY GREATER THAN ALL TIME1'S
    
comm.Barrier()
NsendAll(array,MPI.Wtime())  
        



