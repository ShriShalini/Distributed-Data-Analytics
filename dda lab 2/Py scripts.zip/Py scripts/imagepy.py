
import numpy as np
import cv2
from mpi4py import MPI
import sys
import matplotlib.pyplot as plt

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()


if(rank==0):
    
    img = cv2.imread('imggray.jpg',0)
    
    splitted_array = np.array_split(img, size) 
	
    
    
else:
    splitted_array = None


data = comm.scatter(splitted_array,root=0)


frequency_dict = dict()
if(rank!=0 or rank==0):
    

    for i in range(len(data)):
        
        for j in range(len(data[i])):
            if data[i][j] in frequency_dict:
                frequency_dict[data[i][j]]+=1
            else:
                frequency_dict[data[i][j]]=1
    


data_frequency = comm.gather(frequency_dict,root=0)

if(rank==0):
    

    result_dict = data_frequency[0]
    for i in range(1,len(data_frequency)):
        for key in data_frequency[i]: 
            if key in result_dict: 
                result_dict[key] += data_frequency[i][key]
            else: 
                result_dict[key] = data_frequency[i][key] 
    print('final frequency', result_dict,'sda')
    
    plt.axis([0, 300, 0, 1500000])
    plt.bar(result_dict.keys(), result_dict.values())
    plt.(result_dict,256,[0,256])
    plt.title('Histogram for water.jpg Grayscale') 
    plt.xlabel('Gray scale values')
    plt.ylabel('Frequency')
    plt.show()
    


  

  
























