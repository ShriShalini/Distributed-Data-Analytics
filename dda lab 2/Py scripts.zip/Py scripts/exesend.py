import numpy as np
import sys
from mpi4py import MPI

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()



args = list(sys.argv)
input_size = int(args[1])
np.random.seed(5)
n=input_size
array = np.random.random((1,n))
time = MPI.Wtime() 
def EsendAll(array):
    if rank==0:
	    if(1<size):
		    comm.Send([array,MPI.FLOAT],dest=1)
	    if(2<size):
		    comm.Send([array,MPI.FLOAT],dest=2)
    else:
        data_buffer = np.empty((1,n),dtype=float)
        comm.Recv([data_buffer,MPI.FLOAT],source=int((rank-1)/2))
        if(2*rank+1 < size):
            comm.Send([array,MPI.FLOAT],dest=(2*rank+1))
        if(2*rank+2 < size):	
            comm.Send([array,MPI.FLOAT],dest=(2*rank+2))
    comm.Barrier() #MAKES ALL TIME2 STRICTLY GREATER THAN ALL TIME1'S
    
    
    

comm.Barrier()
EsendAll(array)


