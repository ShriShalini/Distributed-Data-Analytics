
# coding: utf-8

# <h1>Exercise 4: Custom Losses in Convolutional Neural Networks on
# the MNIST dataset

# In[1]:


import torch
import torchvision
import torchvision.datasets as datasets
import torchvision.transforms as transforms
transform = transforms.Compose([transforms.ToTensor(),
  transforms.Normalize((0.5,), (0.5,))
])
#loading the MNIST dataset
trainset = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=1,
                                          shuffle=True, num_workers=2)
testset = datasets.MNIST(root='./data', train=False,
                                       download=True, transform=transform)
testloader = torch.utils.data.DataLoader(testset, batch_size=1,
                                         shuffle=False, num_workers=2)


# In[29]:


#defining classes for regression 
#classes for regression is same as the classes for classification except that the classes will be an integer
classes = ('0','1','2','3','4','5','6','7','8','9')


# In[30]:


print(len(trainset),len(testset))


# <b>Train test split</b>
# <p> The total size of dataset is 70000<p>
# <p> 60000 records are used for training</p>
# <p> 10000 records are used for testing</p>
# 

# In[3]:


import matplotlib.pyplot as plt
import numpy as np




def imshow(img):
    img = img / 2 + 0.5    
    npimg = img.numpy()
    plt.imshow(np.transpose(npimg, (1, 2, 0)))
    plt.show()
#printing an image
dataiter = iter(trainloader)
images, labels = dataiter.next()
imshow(torchvision.utils.make_grid(images))
# print labels
print(' '.join('%5s' % classes[labels[j]] for j in range(1)))


# <B>Structure</B>
# <p>First layer:  Convolutional layer, taken in one channel, gives out 6 channels</p>
# <p>Second layer: MaxPool layer, dimension does not change</p>
# <p>Third layer:  Convolutional layer, taken in 6 channels, gives out 16 channels</p>
# <p>Fourth layer: MaxPool layer, dimension does not change</p>
# <p>Fifth layer: Fully connected layer that takes flattened output of fourth layer</p>
# 
# <b>Classification head</b>
# <p>Takes output from the fifth layer<p>
# <p>First layer in classification head: Fullyconnected layer than takes output from fifth layer and gives out output of dimension 1X84<p>
# <p>Second layer in classification head: Fullyconnected layer than takes output from first layer in classif head and gives out output of dimension 40<p>
# 
# <b>Regression head</b>
# <p>First layer: Fully connected layer than takes output from fifth layer and gives output of size 50<p>
# <p>Second layer: Fully connected layer than takes output from first layer in reg head and gives output of size 25<p>
# <p>third layer: Fully connected layer than takes output from fifth layer and gives output of size 1<p>
# 
# 
# 
# 

# In[7]:


import torch.nn as nn
import torch.nn.functional as F

#multi task setting

class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 6, 5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(256, 120)
        self.classif1 = nn.Linear(120, 84)
        self.classif2 = nn.Linear(84, 10)
        
        self.fcreg1 = nn.Linear(120, 50)
        self.fcreg2 = nn.Linear(50,25)
        self.fcreg3 = nn.Linear(25,1)

        
    def forward(self, x):
        
        x = self.pool(F.relu(self.conv1(x)))
        
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1,256)
        x = F.relu(self.fc1(x))
        classif = F.relu(self.classif1(x))
        classif = self.classif2(classif)
        
        reg = F.relu(self.fcreg1(x))
        reg = F.relu(self.fcreg2(reg))
        reg = self.fcreg3(reg)
        
        return [classif,reg]
    

net = Net()


# In[8]:


import torch.optim as optim
#Stochastic gradient descent
optimizer = optim.SGD(net.parameters(), lr=0.001, momentum=0.9)


# In[28]:


#


# In[11]:


def custom_loss_crossentropy(x,y):
    log_prob = -1.0 * F.log_softmax(x, 1)
    loss = log_prob.gather(1, y.unsqueeze(1))
    loss = loss.mean()
    return loss
def custom_loss_mse(output, target):
    loss = torch.mean((output - target)**2)
    return loss
class_loss = []
reg_loss = []
loss_list = []
#Running for three epochs
for epoch in range(3):  
    print('epoch',epoch)
    running_loss = 0.0
    #Iterating over training dataset
    for i, data in enumerate(trainloader, 0):
        
        inputs, labels = data

        #zeroing the gradients
        optimizer.zero_grad()
        #Feeding inputs to the model
        outputs = net(inputs)
        #Classification loss is a crossentropy loss
        class_l = custom_loss_crossentropy(outputs[0], labels)
        #Regression loss is a Mean Squared Error loss
        reg_l = custom_loss_mse(outputs[1], int(labels))
        #Loss is the combination of classification loss and regression loss
        loss = class_l+reg_l
        loss_list.append(loss)
        class_loss.append(class_l)
        reg_loss.append(reg_l)
        #Backpropagation of errors
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
        if i % 2000 == 1999:    
            print('[%d, %5d] loss: %.3f' %
                  (epoch + 1, i + 1, running_loss / 2000))
            running_loss = 0.0

print('Finished Training')


# <b>Classification loss</b>
# <p>Loss for the final minibatch is 2.3065</p> 
# <b>Regression loss</b>
# <p>Loss for the final minibatch is 8.2815</p> 
# <p>Total loss for final minibatch is 10.5880</p>

# In[27]:



print(sum(class_loss[-2000:])/2000)
print(sum(reg_loss[-2000:])/2000)
print(sum(loss_list[-2000:])/2000)


# In[19]:


dataiter = iter(testloader)
images, labels = dataiter.next()

# print images
imshow(torchvision.utils.make_grid(images))
print('GroundTruth: ', ' '.join('%5s' % classes[labels[j]] for j in range(1)))


# In[81]:


outputs = net(images)


# In[82]:


_, predicted = torch.max(outputs[0], 1)
print(outputs[1])
print('Predicted: ', ' '.join('%5s' % classes[predicted[j]]
                              for j in range(1)))


# In[23]:


correct = 0
total = 0
with torch.no_grad():
    for data in testloader:
        images, labels = data
        outputs = net(images)
        _, predicted = torch.max(outputs[0].data, 1)
        predicted2 = outputs[1]
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

print('Accuracy of the network on the 10000 test images: %d %%' % (
    100 * correct / total))


# <b>Accuracy for classification</b>
# <p>11%</p>
# <p>It does not perform good after introducing regression head</p>
# <p>Regression loss does not converge much</p>
# 
